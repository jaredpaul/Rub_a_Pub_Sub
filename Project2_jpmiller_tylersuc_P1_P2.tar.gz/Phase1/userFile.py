a = 3
b = 6
print(a+b)